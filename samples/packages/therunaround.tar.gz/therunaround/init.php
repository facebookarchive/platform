<?php

include_once MAIN_PATH.'/lib/config.php';
include_once MAIN_PATH.'/lib/core.php';
include_once MAIN_PATH.'/lib/display.php';
include_once MAIN_PATH.'/lib/fbconnect.php';
include_once MAIN_PATH.'/lib/friends.php';
include_once MAIN_PATH.'/lib/run.php';
include_once MAIN_PATH.'/lib/user.php';
include_once MAIN_PATH.'/facebook-client/facebook.php';

