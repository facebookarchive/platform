<?php

  // Profile page for a user

$id = idx($_GET, 'id');

echo 'User ' . $id;
