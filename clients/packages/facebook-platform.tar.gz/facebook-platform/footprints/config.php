<?php

include_once $_SERVER['PHP_ROOT'].'/password.php';

$db_ip = '10.1.200.128';
$db_user = 'root';
$db_name = 'ari';
$api_key = 'aef90d6491c8a0ada5b68a6c5aebb8fa';
$secret  = 'bf00b8c12ebbde3b6ea018b56b9d82a3';
